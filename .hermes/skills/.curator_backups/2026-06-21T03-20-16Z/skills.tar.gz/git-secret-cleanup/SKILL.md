---
name: git-secret-cleanup
description: Remove accidentally committed secrets from git history, update .gitignore, and force-push clean history. Covers the full end-to-end workflow with filter-branch, stash management, and ref cleanup.
category: devops
---

# Git Secret Cleanup

End-to-end workflow for removing secrets from git history and preventing future leaks via `.gitignore`. Designed for the knowledge-base repo but applicable to any repo.

## When to use

- GitHub push protection blocks a push due to secrets in history
- Secrets (API keys, OAuth tokens) accidentally committed
- Need to rewrite history to purge sensitive files AND prevent re-occurrence

## Prerequisites

- Push access to the remote (SSH key or valid GitHub token)
- No pending work that can't be recreated (history rewrite is destructive)
- Other collaborators must be notified — they'll need `git reset --hard origin/master` after

## Workflow

### Step 1: Backup

```bash
cp -r .git /tmp/repo-name-git-backup
```

### Step 2: Identify secret files

```bash
# GitHub will tell you the exact paths in the push rejection message
# e.g., .hermes/auth/google_oauth.json, .hermes/auth.json
```

### Step 3: Delete files from disk

```bash
rm -rf .hermes/auth/
```

### Step 4: Clean working directory completely

`filter-branch` is extremely strict — it will fail with "You have unstaged changes"
even when `git stash --all` appears to clear everything. This is because submodule
dirty state and certain modified files survive stash. Do NOT skip any of these:

```bash
# Stash everything including untracked and ignored
git stash push --all -m "temp-stash-before-filter"

# Discard any remaining modifications
git checkout .

# Force-delete any remaining untracked files (critical!)
git clean -fd   # requires approval for force delete

# Verify: git status must show NOTHING
git status
```

**If filter-branch STILL fails:** `git status --short` and `git checkout --` each
modified file individually. Submodule entries (`m <path>`) can be ignored.

### Step 5: Run filter-branch

```bash
FILTER_BRANCH_SQUELCH_WARNING=1 git filter-branch --force \
  --index-filter 'git rm -rf --cached --ignore-unmatch .hermes/auth/' \
  --prune-empty --tag-name-filter cat -- --all
```

**Pitfall:** If filter-branch fails with "You have unstaged changes" even after stash, check `git status` — there may be modified files not covered by stash. Use `git checkout -- <file>` for each.

### Step 6: Clean refs/original/ (filter-branch backup refs)

```bash
for ref in $(git for-each-ref --format="%(refname)" refs/original/); do
  git update-ref -d "$ref"
done
git reflog expire --expire=now --all
git gc --prune=now --aggressive
```

### Step 7: Update .gitignore

Add entries for the secret files AND related runtime state:

```gitignore
# Hermes auth & session data (không lên git)
.hermes/auth/
.hermes/auth.json
.hermes/channel_directory.json
.hermes/state.db*
.hermes/logs/
.hermes/sessions/
.hermes/cron/
```

Commit: `git add .gitignore && git commit -m "gitignore: exclude secrets and runtime state"`

### Step 8: Restore working files (optional)

```bash
git stash list        # find the right stash
git stash pop stash@{N}
```

### Step 9: Verify history is clean

```bash
git log --oneline master -- .hermes/auth/    # should be empty
git show master:.hermes/auth/google_oauth.json  # should fail with "NOT IN"
```

### Step 10: Force push

```bash
git push --force-with-lease origin master
```

## Knowledge-base specific .gitignore

The full Hermes exclusion set for this project:

```gitignore
.hermes/auth/
.hermes/auth.json
.hermes/channel_directory.json
.hermes/state.db*
.hermes/logs/
.hermes/sessions/
.hermes/cron/
```

Combined with Obsidian exclusions:

```gitignore
.obsidian/workspace.json
.obsidian/workspace-mobile.json
.obsidian/cache
```

## Pitfalls

- **filter-branch needs pristine working tree** — stash ALL changes including untracked (`--all`), then `git checkout .` then `git clean -fd`. Submodule dirty state (`m <path>`) is harmless and can be ignored.
- **Stash conflicts on pop** — stash may conflict with filter-branch rewritten files. Drop conflicting stashes and let them regenerate naturally.
- **No credential** — HTTPS remotes with no credential helper will fail. Check with `ssh -T git@github.com` or `gh auth status`. If neither works, the push must be done from a machine with valid GitHub auth.
- **Other machines must reset** — after force push, other clones need `git fetch origin && git reset --hard origin/master`, NOT a normal pull.
- **.gitignore does NOT untrack already-committed files** — after filter-branch, files you added to `.gitignore` may still appear in `git status` as tracked. You must explicitly `git rm --cached` each one, then commit. Always run `git ls-files <pattern>` to find stragglers, then `git rm --cached` them all before the final commit.
- **Session/state files constantly regenerate** — `.hermes/sessions/*.json`, `state.db*`, `.jsonl` files are recreated every time the agent runs. Make sure ALL variants are in `.gitignore` AND `git rm --cached`'d.
- **Submodule dirty state is harmless** — `m .hermes/hermes-agent` in `git status --short` means a submodule has modified content. This does NOT block filter-branch. Ignore it.
- **After `git rm --cached`, git status shows files as both deleted (`D`) and untracked (`??`)** — this is normal and expected. The `D` means staged-as-deleted (no longer tracked), `??` means the file still exists on disk but is now ignored by `.gitignore`. Both are correct.
- **GitHub credential on remote machine** — if the agent is running on a VPS without GitHub credential helper, the final `git push` will fail with "could not read Username". Check `gh auth status` or `ssh -T git@github.com` first. The actual push must be done from a machine with valid GitHub auth (e.g., Julius's main machine or CLI with a personal access token).
- **OpenClaw gateway pairing** — if `openclaw` CLI commands fail with "pairing required" or "GatewayClientRequestError", the CLI client is an unapproved device. Fix with `openclaw devices list` then `openclaw devices approve <request-id>`. The gateway process and CLI tool use separate auth — Telegram bots may work fine while CLI is blocked.
- **After filter-branch, .gitignore alone won't stop tracked files from appearing** — must run `git ls-files <pattern>` to find all tracked stragglers, then `git rm --cached` each one, commit, and push. Files like `.jsonl` sessions, `.log` files, and `state.db-wal`/`state.db-shm` are commonly missed.

## Obsidian config conflict resolution

When `.obsidian/graph.json` or `.obsidian/workspace.json` cause merge conflicts between machines (common with Obsidian Git plugin auto-sync):

```bash
# Resolve conflict — keep local version
git checkout --ours .obsidian/graph.json .obsidian/workspace.json
git add .obsidian/graph.json .obsidian/workspace.json

# Untrack permanently so this never happens again
git rm --cached .obsidian/graph.json .obsidian/workspace.json
git commit -m "untrack Obsidian UI config: graph.json + workspace.json"

# Also add to .gitignore if not already there
echo ".obsidian/graph.json" >> .gitignore
echo ".obsidian/workspace.json" >> .gitignore
git add .gitignore
git commit -m "gitignore: add Obsidian UI config"
```

**Why this happens:** Obsidian Git plugin tracks these files (UI state — graph zoom, panel position), and they change every session on each machine. Untracking them stops the cycle permanently.

## HTTPS → SSH migration

When `git push` fails with "Invalid username or token. Password authentication is not supported", GitHub has blocked HTTPS password auth. Check for SSH key:

```bash
ls ~/.ssh/id_*
```

**If key exists** (e.g., `id_ed25519.pub`):
```bash
git remote set-url origin git@github.com:USERNAME/REPO.git
git push origin master
```

**If no key** — generate one, add to https://github.com/settings/keys, then switch remote as above.

## Two-machine sync after history rewrite

After force push from any machine, the other machine must:
```bash
git fetch origin && git reset --hard origin/master
```
Normal `git pull` will fail with divergence errors. `reset --hard` discards local history and aligns with remote. Untracked files (like autogenerated session files) are unaffected.

## Recovery

If filter-branch goes wrong: restore from `/tmp/repo-name-git-backup`:

```bash
rm -rf .git
cp -r /tmp/repo-name-git-backup .git
git reset --hard HEAD
```
